window.addEventListener("load", (event)=>{
    console.log("hello from javascript!")
})